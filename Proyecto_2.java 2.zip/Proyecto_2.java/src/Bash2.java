import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Bash2 {

    public  void ejecutar() {


        Scanner scanner = new Scanner(System.in);

        try {

            Process p = Runtime.getRuntime().exec("./bash/bashactividades.sh");
            BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = null;

            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

}
