import java.util.Scanner;
public class Controlador {

    public void controlador(){

        Bash1 bash1 =new Bash1();
        Bash2 bash2 = new Bash2();
        Bash3 bash3 = new Bash3();
        Bash4 bash4 = new Bash4();
        Scanner sc = new Scanner(System.in);
        String respuesta;

        bash1.ejecutar();

        System.out.println("Desea visualizar a los ususrios del sistema? si/no ");

        respuesta = sc.nextLine();

        if (respuesta.equals("si"))
        {
            bash2.ejecutar();
        }

        System.out.println("Desea visualizar ficheros y prosesos? si/no ");

        respuesta = sc.nextLine();

        if (respuesta.equals("si"))
        {
            bash3.ejecutar();
        }

        System.out.println("Desea visualizar la actividad de los usuarios? si/no ");

        respuesta = sc.nextLine();

        if (respuesta.equals("si"))
        {
            bash4.ejecutar();
        }








        bash2.ejecutar();

    }



}
