public class Controlador {

    public void controlador(){

        Bash1 bash1 =new Bash1();
        Bash2 bash2 = new Bash2();
        Bash3 bash3 = new Bash3();
        Bash4 bash4 = new Bash4();

        bash1.ejecutar();

        System.out.println("Desea visualizar a los ususrios del sistema");



        bash2.ejecutar();

    }



}
