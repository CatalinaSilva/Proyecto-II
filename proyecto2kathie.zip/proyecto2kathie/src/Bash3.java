import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Bash3 {

    public  void ejecutar() {
        String opcion;


        Scanner scanner = new Scanner(System.in);

        try {

            Process p = Runtime.getRuntime().exec("bash/bash3.sh");
            BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = null;

            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        try {
            System.out.println("Escriba la letra o palabra por la cual desea \n encontar un fichero");
            opcion= scanner.nextLine();

            Process p = Runtime.getRuntime().exec("bash/bash3_2.sh + opcion");
            BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = null;

            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

}
