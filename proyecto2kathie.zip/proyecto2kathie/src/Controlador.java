import java.util.Scanner;
public class Controlador {

    public void controlador(){

        Bash1 bash1 =new Bash1();
        Bash2 bash2 = new Bash2();
        Bash3 bash3 = new Bash3();
        Bash4 bash4 = new Bash4();
        Scanner sc = new Scanner(System.in);
        String respuesta;
        String opciones;

        bash1.ejecutar();

        System.out.println("Desea visualizar a los usuarios del sistema? si/no ");

        respuesta = sc.nextLine();

        if (respuesta.equals("si"))
        {
            bash2.ejecutar();
        }

        System.out.println("Desea entrar a la opcion de  ficheros y prosesos? si/no ");

        respuesta = sc.nextLine();

        if (respuesta.equals("si"))
        {
            bash3.ejecutar();
        }

        System.out.println("Desea entrar a opcion de actividades de los usuarios? si/no ");

        respuesta = sc.nextLine();

        if (respuesta.equals("si"))
        {
            bash4.ejecutar();
        }


    }



}
