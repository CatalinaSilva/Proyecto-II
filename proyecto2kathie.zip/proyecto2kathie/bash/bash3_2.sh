#!/bin/bash


 
opcion=$1
 

 if [ `ls $HOME | grep -i "$opcion" | head -n 1` ]; then
	readlink -f `ls | grep -i "$opcion"`
	
	echo
	echo " ------------------------"
	
 else 
 echo "No hay coincidencias"
 echo "----------------------------"
 
 fi
