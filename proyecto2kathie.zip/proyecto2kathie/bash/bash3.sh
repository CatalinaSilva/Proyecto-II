 #!/bin/bash 
 
 echo "los directorios son:"
 echo
 ls -F | grep "/" | cut -d "/" -f1 | sort
 echo
 echo "---------------------------------"
 echo "los Archivos son:"
 echo
 ls -F | grep -v  "/" | cut -d "." -f1 | sort
 echo
 echo "----------------------------------"
 
 echo 
 echo "ficheros mayores a 1024k ordenados por tamanio"

 ls -lS $HOME |awk ' $5>1024000 {print $9 "  " ($5/1024) "kB" }'
 echo
 echo "------------------------------------"

	
 
 
 
 
