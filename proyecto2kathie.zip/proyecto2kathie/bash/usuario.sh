#!/bin/bash

MODIFICADO=`find $HOME -mtime 0`
TIEMP=`who -a`


echo "Los archivos modificados en las ultimas 24 horas son:\n$MODIFICADO"
echo
echo "------------------------------------------------"
echo "Los usuarios conectados son: $TIEMP."
echo
echo "------------------------------------------------"
