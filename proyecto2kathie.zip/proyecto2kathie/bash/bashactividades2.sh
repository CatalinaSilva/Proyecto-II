

	opcion=$1

	if [ `cat /etc/passwd | cut -d":" -f1 |grep "$opcion"| head -n 1` ]; then
		echo "Coincidencias:" 
		echo
		cat /etc/passwd | cut -d":" -f1 |grep "$opcion"
	else
		echo "No hay coincidencias"
	fi

	echo "------------------------------------------------------------"

		
